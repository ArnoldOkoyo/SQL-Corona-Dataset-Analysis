-- Comparative Analysis: Integrate daily and summary data to assess daily changes against overall trends

SELECT 
    s.country,                                      -- Country name
    s.continent,                                    -- Continent name
    s.total_confirmed,                              -- Total confirmed cases from summary
    s.total_deaths,                                 -- Total deaths from summary
    s.total_recovered,                              -- Total recovered cases from summary
    s.active_cases,                                 -- Active cases from summary
    s.serious_or_critical,                          -- Serious or critical cases from summary
    s.total_cases_per_1m_population,               -- Total cases per million population from summary
    s.total_deaths_per_1m_population,              -- Total deaths per million population from summary
    s.total_tests,                                  -- Total tests from summary
    s.total_tests_per_1m_population,               -- Total tests per million population from summary
    s.population,                                   -- Population of the country
    d.date,                                         -- Date of report
    SUM(TRY_CAST(d.daily_new_cases AS INT)) AS daily_new_cases,  -- Daily new cases from daily data
    SUM(TRY_CAST(d.daily_new_deaths AS INT)) AS daily_new_deaths, -- Daily new deaths from daily data
    SUM(TRY_CAST(d.active_cases AS INT)) AS daily_active_cases,    -- Total active cases for the day

    -- Calculate daily changes against overall trends using TRY_CAST
    (SUM(TRY_CAST(d.daily_new_cases AS INT)) * 1.0 / NULLIF(s.total_confirmed, 0)) * 100 AS daily_new_cases_percentage, -- Percentage of new cases
    (SUM(TRY_CAST(d.daily_new_deaths AS INT)) * 1.0 / NULLIF(s.total_deaths, 0)) * 100 AS daily_new_deaths_percentage    -- Percentage of new deaths

FROM 
    [dbo].[worldometer_summary] AS s
JOIN 
    [dbo].[worldometer_daily] AS d ON s.country = d.country  -- Join summary and daily tables on 'country'

WHERE 
    d.daily_new_cases NOT IN ('NA', '') AND             -- Exclude non-numeric values for daily new cases
    d.daily_new_deaths NOT IN ('NA', '') AND            -- Exclude non-numeric values for daily new deaths
    d.active_cases NOT IN ('NA', '')                     -- Exclude non-numeric values for active cases

GROUP BY 
    s.country, s.continent, s.total_confirmed, s.total_deaths, 
    s.total_recovered, s.active_cases, s.serious_or_critical, 
    s.total_cases_per_1m_population, s.total_deaths_per_1m_population, 
    s.total_tests, s.total_tests_per_1m_population, s.population, 
    d.date                                     -- Group data by necessary fields

ORDER BY 
    s.continent, s.country, d.date;                          -- Order by continent, country, and date


