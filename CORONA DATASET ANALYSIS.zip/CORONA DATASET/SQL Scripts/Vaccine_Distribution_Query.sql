-- Analyze vaccination distribution and rate of administration by country and continent

SELECT 
    s.continent,                                    -- Continent name
    s.country,                                      -- Country name
    s.population,                                   -- Population of the country
    s.total_tests AS total_tests_administered,      -- Total tests administered
    s.total_tests_per_1m_population AS tests_per_million,  -- Tests per million as a proxy for intervention reach
    
    -- Calculate total cases and deaths per million as a proxy for health intervention outcomes
    s.total_cases_per_1m_population AS cases_per_million,
    s.total_deaths_per_1m_population AS deaths_per_million,
    
    -- Calculate daily and cumulative metrics for tracking health intervention rates over time
    d.date,                                          -- Date of report
    SUM(CASE WHEN ISNUMERIC(d.daily_new_cases) = 1 
             THEN CAST(d.daily_new_cases AS INT) ELSE 0 END) AS daily_new_cases,       -- New cases each day

    SUM(CASE WHEN ISNUMERIC(d.daily_new_deaths) = 1 
             THEN CAST(d.daily_new_deaths AS INT) ELSE 0 END) AS daily_new_deaths,     -- New deaths each day
    
    -- Calculate cumulative cases and deaths over time
    SUM(SUM(CASE WHEN ISNUMERIC(d.daily_new_cases) = 1 
                 THEN CAST(d.daily_new_cases AS INT) ELSE 0 END)) 
        OVER (PARTITION BY s.continent, s.country ORDER BY d.date) AS cumulative_cases,
    
    SUM(SUM(CASE WHEN ISNUMERIC(d.daily_new_deaths) = 1 
                 THEN CAST(d.daily_new_deaths AS INT) ELSE 0 END)) 
        OVER (PARTITION BY s.continent, s.country ORDER BY d.date) AS cumulative_deaths
    
FROM 
    [dbo].[worldometer_summary] AS s
JOIN 
    [dbo].[worldometer_daily] AS d ON s.country = d.country  -- Join summary and daily tables on 'country'

GROUP BY 
    s.continent, s.country, s.population, s.total_tests, 
    s.total_tests_per_1m_population, s.total_cases_per_1m_population, 
    s.total_deaths_per_1m_population, d.date                  -- Group data by continent, country, population, and date

ORDER BY 
    s.continent, s.country, d.date;

