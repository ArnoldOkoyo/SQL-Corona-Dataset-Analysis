-- Calculate infection and fatality trends by continent and country over time

/*SELECT 
    s.[continent],                      -- Continent name
    d.[country],                        -- Country name
    d.[date],                    -- Date of report
    SUM(d.[daily_new_cases]) AS daily_infections,   -- Total new cases for each day
    
    SUM(d.[daily_new_deaths]) AS daily_fatalities,    -- Total new deaths for each day

    -- Calculate cumulative counts for infections and fatalities
    SUM(SUM(d.[daily_new_cases])) OVER (PARTITION BY s.[continent], d.[country] ORDER BY d.[date]) AS cumulative_infections,
    
    SUM(SUM(d.[daily_new_deaths])) OVER (PARTITION BY s.[continent], d.[country] ORDER BY d.[date]) AS cumulative_fatalities

FROM 
    [dbo].[worldometer_daily] AS d
JOIN
    [dbo].[worldometer_summary] AS s ON  d.[country]= s.[country]  -- Join summary and daily tables on 'country'
    


GROUP BY 
    s.[continent], d.[country], d.[date]              -- Group data by continent, country, and date

ORDER BY 
    s.[continent], d.[country], d.[date];*/

	-- Calculate infection and fatality trends by continent and country over time

-- Calculate infection and fatality trends by continent and country over time

SELECT 
    s.[continent],                                    -- Continent name
    d.[country],                                      -- Country name
    d.[date],                                         -- Date of report
    SUM(CASE WHEN ISNUMERIC(d.[daily_new_cases]) = 1 
             THEN CAST(d.[daily_new_cases] AS INT) ELSE 0 END) AS daily_infections,    -- Convert numeric values only, treat others as 0
             
    SUM(CASE WHEN ISNUMERIC(d.[daily_new_deaths]) = 1 
             THEN CAST(d.[daily_new_deaths] AS INT) ELSE 0 END) AS daily_fatalities,   -- Convert numeric values only, treat others as 0

    -- Calculate cumulative counts for infections and fatalities
    SUM(SUM(CASE WHEN ISNUMERIC(d.[daily_new_cases]) = 1 
                 THEN CAST(d.[daily_new_cases] AS INT) ELSE 0 END)) 
        OVER (PARTITION BY s.[continent], d.[country] ORDER BY d.[date]) AS cumulative_infections,
    
    SUM(SUM(CASE WHEN ISNUMERIC(d.[daily_new_deaths]) = 1 
                 THEN CAST(d.[daily_new_deaths] AS INT) ELSE 0 END)) 
        OVER (PARTITION BY s.[continent], d.[country] ORDER BY d.[date]) AS cumulative_fatalities

FROM 
    [dbo].[worldometer_daily] AS d
JOIN
    [dbo].[worldometer_summary] AS s ON d.[country] = s.[country]  -- Join summary and daily tables on 'country'

GROUP BY 
    s.[continent], d.[country], d.[date]                          -- Group data by continent, country, and date

ORDER BY 
    s.[continent], d.[country], d.[date];

